<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    
    <style type="text/css">
        body{ font: 14px sans-serif; 
              text-align: center; 
              background-image: url("Uplay/b.jfif");
              background-repeat: no-repeat;
              background-size: cover;
              }
        /* Style the links inside the sidenav */
#mySidenav a {
  position: absolute; /* Position them relative to the browser window */
  left: -80px; /* Position them outside of the screen */
  transition: 0.3s; /* Add transition on hover */
  padding: 15px; /* 15px padding */
  width: 100px; /* Set a specific width */
  text-decoration: none; /* Remove underline */
  font-size: 20px; /* Increase font size */
  color: white; /* White text color */
  border-radius: 0 5px 5px 0; /* Rounded corners on the top right and bottom right side */
}

#mySidenav a:hover {
  left: 0; /* On mouse-over, make the elements appear as they should */
}

/* The about link: 20px from the top with a green background */
#Welcome {
  top: 20px;
  background-color: #4CAF50;
}

#Login {
  top: 80px;
  background-color: #2196F3; /* Blue */
}

#Signup {
  top: 140px;
  background-color: #f44336; /* Red */
}

#Contact {
  top: 200px;
  background-color: #555 /* Light Black */
}

h1{
    color: white;
    font-size: 150px;
}
    </style>
</head>
<body>

<div id="mySidenav" class="sidenav">
  <a href="Welcomeus.php" id="Welcome">Home</a>
  <a href="login.php" id="Login">Login</a>
  <a href="register.php" id="Signup">Register</a>
  <a href="contact.php" id="Contact">Contact Us</a>
</div>
        <h1>Taxis Online</h1>
</body>
</html>