-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2021 at 02:26 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `taxi`
--

CREATE TABLE `taxi` (
  `taxi_id` int(11) NOT NULL,
  `Taxi_username` varchar(50) NOT NULL,
  `Taxi location` varchar(255) NOT NULL,
  `Taxi Price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxi`
--

INSERT INTO `taxi` (`taxi_id`, `Taxi_username`, `Taxi location`, `Taxi Price`) VALUES
(1, 'James', 'Dorado Valley', 16);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(14, 'Vetutekule', '$2y$10$cLa4c3gbhO7n2EWQ0pbtRuVlCanpXUDdWFXpfxsJHLdPpRMEUHkj.', '2021-01-28 16:59:51'),
(15, 'Yeehaw', '$2y$10$vLhYX.eF9sD2xqOsQ3QoUOY1/FjAHDm1EZzNlO22uhu2ETlCEgUJW', '2021-01-29 19:30:01'),
(16, 'paul', '$2y$10$0HFpjEpHYtUJJsxjB1iSSe.S37SEQrj.0mnNMb2cmywBeNHgXOTsO', '2021-01-30 11:22:16'),
(17, '', '$2y$10$CqagxKH2LtXrKDGCYslfXO.3bONpGT7XHHocUQUQG6I87uHHfHupq', '2021-01-31 21:11:18'),
(20, 'philip', '$2y$10$oVS8AI8EjDlPQyd5RofE3.L0QlIdUgGFKvXnDcUi77eyMGm62.B.m', '2021-01-31 21:19:35'),
(21, 'James', '$2y$10$RIb33wyt7aUHCQAM20oOlOZm7zeMcOuznkdX7VZRBucRMRjzKqQQa', '2021-01-31 22:31:46'),
(22, 'kal', '$2y$10$GMtAoTxUGYUU8H8l6C6LB.bX3v7ndRLyepB6iW3QrtoGhSV0OfCXu', '2021-02-01 13:27:16'),
(23, 'BEN', '$2y$10$Ty40owYyXVF4HB56UUfbyOrkRSI79qyUmMOdC216qK1.F2HQd.U0i', '2021-02-08 13:51:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `taxi`
--
ALTER TABLE `taxi`
  ADD PRIMARY KEY (`taxi_id`),
  ADD UNIQUE KEY `Taxi_username` (`Taxi_username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `taxi`
--
ALTER TABLE `taxi`
  MODIFY `taxi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
