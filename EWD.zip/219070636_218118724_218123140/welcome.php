<?php
// Initialize the session 
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Interface/main function page</title>
   
    <style type="text/css">
        body{ font: 14px sans-serif; 
            
              text-align: center; 
              background-image: url("Uplay/b.jfif");
              background-repeat: no-repeat;
              background-size: cover;
              }

 .form { 
 margin: 0 auto; 
 width:250px;
 }

 .form2 { 
 margin: 100 auto; 
 width:250px;
 border: 24px;
 }

 th{
     color:white;
 }
 tr{
     color:white;
 }

 h1{
     color:white;
 }

    </style>
</head>
<body>

    <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>.Would you like to make a call</h1>
    </div>
    
    <p>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    
    </p>

<div class="form2">
<h1>View prices and taxi details</h1>
<form action="welcome.php" method="post">
</form>
</div>

<?php
/* this script is used for viewing the list of taxis */
$con = mysqli_connect("localhost", "root", "", "test");
if(!$con){// Check connection
    die("ERROR: Could not connect. " . mysqli_connect_error());
}// Attempt select query execution
$sql = "SELECT * FROM taxi";
if($result = mysqli_query($con, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table border='1'>";
            echo "<tr>";
                echo "<th>id</th>";
                echo "<th>driver name</th>";
                echo "<th>location</th>";
                echo "<th>price</th>";
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['taxi_id'] . "</td>";
                echo "<td>" . $row['Taxi_username'] . "</td>";
                echo "<td>" . $row['Taxi location'] . "</td>";
                echo "<td>" . $row['Taxi Price'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        mysqli_free_result($result);// Free result set
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
} 
mysqli_close($con);// Close connection
?>

<div class="form">
<form method="post" action="welcome.php">
  <h1>Make Call</h1>
  <input type="submit" value="Make call"/>
  
</form>
</div>

</body>
</html>